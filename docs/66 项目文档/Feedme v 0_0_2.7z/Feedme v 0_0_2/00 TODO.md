# TODO

- 建立本地sqlite3数据库表：包括baostock_K线表, efinanceK线表；ok
- 建立fm的，基于click的命令行接口
  - bs下载接口 ok
  - ef下载接口 ok
- 开发下载存量Baostock的程序，包括写入数据库 ok
- 存量下载Baostock的程序，加入覆盖更新功能；
- 开发下载存量efinance的程序，包括写入数据库 ok
- 存量下载efinance的程序，加入覆盖更新功能；
- efinance数据网关 ok
- baostock数据网关 ok
- tl公共模块，访问sqlite3，使用with模式 ok

OVER